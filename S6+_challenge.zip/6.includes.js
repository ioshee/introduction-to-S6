/* const listIngredients = [ "bread", "chicken", "cheese", "tomato" ];

if (listIngredients.includes("bread")) {
    console.log( "We are going to make a sandwich");
}

else {
    console.log("We can't make a sandwich because we are missing the ingredient salad");
} */


const listIngredients = [ "bread", "chicken", "cheese", "tomato" ];

if (listIngredients.includes("salad")) {
    console.log( "We are going to make a sandwich");
}

else {
    console.log("We can't make a sandwich because we are missing the ingredient salad");
}
