const students = [
{name:"John", city:"New York"},
{name:"Peter", city:"Paris"},
{name:"Kate", city:"Sydney"},
{name:"Tom", city:"Lisbon"},
];
for (const student of students) {
    console.log( student.name + " lives in " + student.city);
}