const shoppingList = ["eggs", "milk", "butter"];

let shoppingBasket = ["cheese" , ...shoppingList, "bread", "chicken"];
console.log(shoppingBasket);