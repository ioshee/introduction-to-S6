/* 
const shoppingTrip = (food = "something") => {
    console.log(`I'm going to buy ${food} from the grocery shop`)
};
shoppingTrip("milk");
 */
//or

function shoppingTrip(food = "something") {
    console.log(`I'm going to buy ${food} from the grocery shop`)
};
shoppingTrip("milk");